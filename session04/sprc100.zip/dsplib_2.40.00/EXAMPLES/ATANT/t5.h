/* Test for maxval: mtst */
#define NX 4
#define FNAME "t5"
#define MAXERROR 40

DATA x[NX] ={
32767,
13572,
6517,
0,
};

DATA rtest[NX] ={
25735,
12867,
6433,
0,
};

DATA r[NX];
