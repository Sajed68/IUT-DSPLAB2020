/* Test for expn: step */
#define NX 7
#define FNAME "t5"
#define MAXERROR 10

DATA x[NX] ={
20,
1020,
2020,
15020,
16020,
31020,
32020,
};

DATA rtest[] ={
4099,
4226,
4356,
6478,
6679,
10556,
10883,
};

DATA r[NX];

