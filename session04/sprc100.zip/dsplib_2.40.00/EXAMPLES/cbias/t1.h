#define NA 8
#define NB 8  // NB <= NA 
#define FNAME "t1"
#define MAXERROR 10  // max absolute error 

DATA a[NA] ={
10429,
-6230,
2475,
-325,
9066,
6072,
-1009,
-11157,
};

DATA b[NB] ={
7447,
-1282,
2674,
6764,
9773,
5519,
-7502,
-2185,
};

DATA rtest[NA+NB-1] ={
-87,
-247,
377,
190,
23,
-279,
-37,
931,
566,
49,
-434,
-70,
64,
26,
-317,
};

