#define NX 5
#define NLAGS 5 // max NLAGS = N 
#define FNAME "t4"
#define MAXERROR 10 // max absolute error allowed 

DATA x[NX] ={
-1765,
-4688,
-5446,
-3955,
-3129,
};

DATA rtest[NLAGS] ={// lag0, lag1,...  
489,
517,
460,
330,
169,
};

