/* Test for bexp: step */
#define NX 7
#define FNAME "t1"
#define MAXERROR 100

DATA x[NX] ={
20,
1020,
-2020,
15020,
16020,
-1020,
-12020,
};

DATA rtest = 1;

DATA r;

