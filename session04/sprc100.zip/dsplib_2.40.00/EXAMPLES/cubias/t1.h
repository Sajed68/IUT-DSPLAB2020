#define NA 8
#define NB 8  // NB <= NA 
#define FNAME "t1"
#define MAXERROR 10  // max absolute error 

DATA a[NA] ={
10429,
-6230,
2475,
-325,
9066,
6072,
-1009,
-11157,
};

DATA b[NB] ={
7447,
-1282,
2674,
6764,
9773,
5519,
-7502,
-2185,
};

DATA rtest[NA+NB-1] ={
-695,
-986,
1006,
379,
36,
-372,
-43,
931,
647,
65,
-694,
-141,
170,
103,
-2536,
};

