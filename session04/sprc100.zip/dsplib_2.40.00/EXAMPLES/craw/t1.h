#define NA 8
#define NB 8  // NB <= NA 
#define FNAME "t1"
#define MAXERROR 10  // max absolute error 

DATA a[NA] ={
10429,
-6230,
2475,
-325,
9066,
6072,
-1009,
-11157,
};

DATA b[NB] ={
7447,
-1282,
2674,
6764,
9773,
5519,
-7502,
-2185,
};

DATA rtest[NA+NB-1] ={
-695,
-1972,
3018,
1516,
182,
-2231,
-298,
7451,
4528,
389,
-3468,
-562,
509,
207,
-2536,
};

