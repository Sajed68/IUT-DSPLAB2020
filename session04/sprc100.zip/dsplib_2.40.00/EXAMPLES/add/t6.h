/* This is a test for add: tst1 */
#define NX 4
#define FNAME "t6"
#define MAXERROR 2

#define ADD_SCALE 0

DATA x[NX] ={
3276,
6553,
9830,
13107,
};

DATA y[NX] ={
328,
655,
983,
1311,
};

DATA rtest[NX] ={
3604,
7209,
10813,
14418,
};

DATA r[NX]; 
