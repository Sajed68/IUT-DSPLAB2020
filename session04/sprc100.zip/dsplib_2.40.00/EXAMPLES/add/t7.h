/* This is a test for add: tst2 */
#define NX 5
#define FNAME "t7"
#define MAXERROR 2

#define ADD_SCALE 0

DATA x[NX] ={
3276,
6553,
9830,
13107,
16384,
};

DATA y[NX] ={
328,
655,
983,
1311,
1638,
};

DATA rtest[NX] ={
3604,
7209,
10813,
14418,
18022,
};

DATA r[NX]; 
