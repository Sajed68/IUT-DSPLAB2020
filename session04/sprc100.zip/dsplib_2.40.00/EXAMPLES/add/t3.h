/* This is a test for add: tst2 */
#define NX 5
#define FNAME "t3"
#define MAXERROR 2

#define ADD_SCALE 1

DATA x[NX] ={
3276,
6553,
9830,
13107,
16384,
};

DATA y[NX] ={
328,
655,
983,
1311,
1638,
};

DATA rtest[NX] ={
1802,
3604,
5407,
7209,
9011,
};

DATA r[NX]; 
