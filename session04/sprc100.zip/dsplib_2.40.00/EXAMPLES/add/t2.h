/* This is a test for add: tst1 */
#define NX 4
#define FNAME "t2"
#define MAXERROR 2

#define ADD_SCALE 1

DATA x[NX] ={
3276,
6553,
9830,
13107,
};

DATA y[NX] ={
328,
655,
983,
1311,
};

DATA rtest[NX] ={
1802,
3604,
5407,
7209,
};

DATA r[NX]; 
