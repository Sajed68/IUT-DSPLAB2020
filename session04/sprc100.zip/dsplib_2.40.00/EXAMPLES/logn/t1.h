/* Test for logn: step */
#define NX 7
#define FNAME "t1"
#define MAXERROR 40

DATA x[NX] ={
20,
1020,
2020,
15020,
16020,
31020,
32020,
};

long rtest[] ={
-242532,
-113693,
-91303,
-25561,
-23449,
-1796,
-757,
};

long r[NX];

