/* Test for div32by32: rand */
#define NX 1
#define FNAME "t1"
#define MAXERROR 10

float x[1] = {
9.002586e-001, 
}; 

DATA rtest[1] = {
29499, 
}; 

DATA r[1];
