/* This is a test for maxidx: rmdn */
#define NX 16
#define FNAME "t4"
#define NG 4
#define NG_SIZE 4
#define MAXERROR 0

DATA x[NX] ={
30720,
28672,
26624,
24576,
22528,
20480,
18432,
16384,
14336,
12288,
10240,
8192,
6144,
4096,
2048,
0,
};

DATA rtest = 0;
DATA r;
