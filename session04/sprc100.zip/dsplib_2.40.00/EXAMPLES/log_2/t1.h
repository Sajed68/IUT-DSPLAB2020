/* Test for logn: step */
#define NX 7
#define FNAME "t1"
#define MAXERROR 100

DATA x[NX] ={
20,
1020,
2020,
15020,
16020,
31020,
32020,
};

long rtest[] ={
-349899,
-164025,
-131723,
-36877,
-33830,
-2592,
-1092,
};

long r[NX];

